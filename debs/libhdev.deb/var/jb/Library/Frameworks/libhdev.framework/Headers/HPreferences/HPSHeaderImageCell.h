#import <Preferences/PSSpecifier.h>
#import "../HUtilities/HCommon.h"

@interface HPSHeaderImageCell : UITableViewHeaderFooterView
@end
